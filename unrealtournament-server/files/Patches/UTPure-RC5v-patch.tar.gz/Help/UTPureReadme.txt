RELEASE CANDIDATE 5v:

Oooops, Fixed the excessive logging problem... sorry about that.

Added: Proximity Warp Removed. This is some wacky code from EPIC that caused players to "Warp"
       when they got too close to you. I have temporarily removed this code, in hope to fix
       it to work the way EPIC originally intended it to work. Let's see if people notice...
Added: Spectator may now use Teleports.
Added: Enhanced TeamSay!! See own section.
Added: Selectable Client Error Position Correction. The Client may select how much error he may
       have in his position (client vs server position) before server forces his update.
       This may be set via the SetMaxClientError x in the console. x is a number between 3 and
       Server Max. The Server Max is set in the UTPureRC5v.int, MaxClientPosError. The default
       value of MaxClientPosError is 100. The Default value everyone gets is 3, which is the
       original Value EPIC coded in.



How to set UTPure
----------------------

add the following lines to [Engine.GameEngine] section of your server ini file:
serveractors=UTPureRC5v.UTPureSA
serverpackages=UTPureRC5v


What can be configured
----------------------

here are the values you can find in UTPureRC5v.int


TrackFOV	 // Track the FOV cheats [0 = no, 1 = strict, 2 = loose]
Advertise	 // Adds [CSHP] to the Server Name [0 = no, 1 = left, 2 = right]
AdvertiseMsg	 // What version to advertise [0 = [CSHP], Not 0 = [PURE] ]
SecurityLevel	 // Level of Security [0 = Nothing, 1 = Kick, 2 = Ban] (Not fully Implemented)
bFastTeams	 // Allow quick teams changes [True or False]
bNGStatsOnly	 // Only allow NGStats Players [True or False] (not done yet)
bNGStatsHack	 // Bypass ngStats (to not be listed under MOD because of UTPure) [True or False]
bAllowCenterview // Allows / Disallow usage of CenterView for keyboard/joystick users [True of False]
bAllowMultiWeapon  // Allows / Disallow usage of the Multi-Weapon exploit [True or False]
CenterViewDelay	 // If Allowed to use Centerview, delay between 2 uses of it [Time in seconds]
bUseClickboard   // Enables/Disables usage of ClickBoard Technology (TM) in Tournament mode. [True or False]
MinClientRate    // Sets the minimum netspeed the client is allowed to use [Default = 1000]
bAdvancedTeamSay // Enable this to allow players to give detailed info about their situation. [True or False]
MaxClientPosError // Sets the Maximum positioning Error the Client May have. [Default = 100.0, Min 3.0]
                  // if you wish to disable this function, set it to 3, which is EPIC's original Value.

HINT: If your server is not listed in MOD section and you wanna keep that status, just set bNGStatsHack to true

NOTE: You can keep the [CSHP] form of advertisement for 2 reasons:
  1) Keep your well defended ngStats position
  2) Make it harder on cheaters to know what is on your server.

Console Commands:
-----------------

Please visit the following page for a complete listing of Console Commands.
- http://www.midnightinteractive.com/forums/showthread.php3?s=&threadid=635

Bonus Pack 1 and 4 Support:
---------------------------

To support the Bonus pack 1 and/or 4 you need to add the handlers for them in UTPureRC5v.int
This is done by default and should be removed if you dont support them.

The UTPureRC5v.int entries look like this:

PlayerPacks[0]=BP1
PlayerPacks[1]=BP4

be carefull, if you want only Bonus Pack 4 use this (check the index):

PlayerPacks[0]=BP4

You must also add ServerPackages entries for the handlers you want to support in the
[Engine.GameEngine] section of your server ini file like the following

ServerPackages=BP1Handler5v
ServerPackages=BP4Handler5v

I believe that both packages are not linked together, so you could add only BP4 support
or BP1 support at your convenience.

Valhalla Avatar Support:
-----------------------------
If you want to support Valhalla Avatar, it must be the only PlayerPack that you use.

It requires the following line in UTPureRC5v.int:

PlayerPacks[0]=VA

and the following line in your ServerPackages:

ServerPackages=VAHandler5v

For more information, check the included VaPure.htm file.

My Personal Suggestions:
------------------------------

-Highly recommended for administration of a server via a command line interface is SemiAdmin. http://pages.infinit.net/darkbyte/filez/SemiAdmin0.07.zip
Read all about SemiAdmin here: http://www.midnightinteractive.com/forums/announcement.php3?s=&forumid=21