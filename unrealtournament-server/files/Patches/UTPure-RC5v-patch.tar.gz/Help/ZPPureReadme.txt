
(zp| readme)


This file tells you how to install Zeroping.  For information on using
Zeroping, see the release notes (installaed to your Unreal Tournament
directory, in Help/Zeroping.html).

Notes for Server Administrators:

 To run a Zeroping game server, you'll need a new line added to the file
 "UnrealTournament.ini".

 The line goes at the bottom of the Engine|GameEngine section
 of C:/UnrealTournament/System/UnrealTournament.ini (or wherever UT is).
 The line is:


    ServerPackages=ZPPure5v


 If you choose to add it manually, this line should come after all other
 "ServerPackages=" lines.

 Either way, you MUST manually remove this line to do any of the following:

 - Start a server without a Zeroping mutator active
 - Install a new version of Zeroping
 - Uninstall Zeroping

 To start a server with Zeroping, select one (and ONLY one) of the ZP
 mutators that appear in your mutator list.


 Following Mutators can be used:

 ZPPure5v.ZeroPing        : Standard weapons use Zero Ping
 ZPPure5v.AccuGib         : Instagib with Zero Ping.
 ZPPure5v.ColorAccuGib    : Zero Ping Instagib with Team Colored Shots.
 ZPPure5v.zp_ShockArena   : Zero Ping Shock Rifle Arena
 ZPPure5v.zp_SniperArena  : Zero Ping Sniper Rifle Arena

Visit:

http://www.midnightinteractive.com/CSHP

For bug rapports/questions/comments regarding ZPPure.


Original ZeroPing by:

John Fraser
zeroping@att.net
http://zeroping.home.att.net/
